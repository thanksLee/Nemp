
------------
MP3FileUtils
------------


Einige Hinweise zu den Demo-Programmen
--------------------------------------


Demo_ID3v1

* Auslesen und schreiben des ID3v1-Tags und der MPEG-Informationen



Demo_ID3v2_Level1

* Lesen und Schreiben des ID3v2-Tags f�r Einsteiger. 
* sehr einfach zu benutzen
* reicht f�r viele Einsatzzwecke aus (z.B. einfache Anzeige f�r 
  einen mp3-Player)



Demo_ID3v2_Level2

* ID3v2 f�r Fortgeschrittene. 
* Verarbeiten spezieller Kommentare, URLs, Bewertungen, Bilder



Demo_ID3v2_Level3

* ID3v2 f�r Experten.
* Manipulation der Daten auf unterster Ebene 
  (darunter geht eigentlich nur noch ein HexEditor)
* Methoden sind mit Vorsicht zu benutzen. 
* Wer nicht wei�, was da passiert, kann da leicht den ID3-Tag
  unbrauchbar machen



DemoUnicode

* Zeigt einige Spielereien bzgl. der Zeichenkodierung im ID3v2Tag. 