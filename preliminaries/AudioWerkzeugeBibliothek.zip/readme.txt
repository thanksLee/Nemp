
----------------------------------------

Audio Werkzeuge Bibliothek (AWB)*

----------------------------------------

    (c) 2012-2016, 
        Daniel Gaussmann
        Website : www.gausi.de
        EMail   : mail@gausi.de

----------------------------------------

A collection of classes to read and write information from 
different kind of audio files.


contains parts of
        Audio Tools Library (ATL)
        http://mac.sourceforge.net/atl/
        e-mail: macteam@users.sourceforge.net

        Copyright (c) 2000-2002 by Jurgen Faul
        Copyright (c) 2003-2005 by The MAC Team

The "Audio Tools Library" is published under the terms of the
GNU Lesser General Public Licence (LGPL).

I tried to contact the MAC-Team for permission to (re)distribute 
the AWB under a dual-licence. I've got no answer.

As the ATL-project seems to be dead for a few years, the used
parts from there are quite small, and I personally want to allow
use of the AWB in closed source software (for beginners ;-)), 
I decided to distribute the AWB under a dual licence without
explicit permission from the developers of the ATL.

    ---------------------------------------------------------------------------

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    ---------------------------------------------------------------------------

    Alternatively, you may use this unit under the terms of the
    MOZILLA PUBLIC LICENSE (MPL):

    The contents of this file are subject to the Mozilla Public License
    Version 1.1 (the "License"); you may not use this file except in
    compliance with the License. You may obtain a copy of the License at
    http://www.mozilla.org/MPL/

    Software distributed under the License is distributed on an "AS IS"
    basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See the
    License for the specific language governing rights and limitations
    under the License.

    ---------------------------------------------------------------------------


_____________________________________________________________

* "Audio Werkzeuge Bibliothek" is word-by-word translation
  of "Audio Tools Library"